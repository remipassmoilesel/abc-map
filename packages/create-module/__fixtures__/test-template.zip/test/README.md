# Abc-Map: plugin template

## TODO

Goal: finish a functional, cheap module system

- un store par module ?
- Déploiement github pages
- Vidéo de présentation du fonctionnement embarquée dans le module
- Objets helpers disponibles partout: window, global, module, ....
- Explain deployment
- Undo / redo simplified capabilities
- Explain all: translation, builder, structure
- Better description and illustration
- All kinds of form compoennts in a simple way
- Pass services to module factory
- Share common interfaces and duplicate types: LayerWrapper, MapWrapper, ...
- Extract common components: layer selector, xlsx loading, ...
- which licence for module template ?
- Better i18n setup, lang does not change, maybe jhust use withTranslation()() ???
- Set proper version for package @abc-map/module-api
- Publish package
- Test setup
- Publish one example on github/gitlab pages
- Simplify template,Simplify template,Simplify template,


## What is this thing ?

TBD

## How to develop a module ?

TBC

Install dependencies:

    $ yarn install

Compile your code:

    $ yarn run watch

Serve your module locally

    $ yarn run server

Then open Abc-Map, go to [data processing](https://abc-map.fr/en/data-processing/).

Open `Load a module`.

Enter your local address: `http://127.0.0.1:7000`, click on `Load`

Enjoy !


## Developing with a local Abc-Map monorepo

Link local module-api package:

    $ cd abc-map/packages/module-api
    $ yarn link

Link local dependency:

    $ yarn link "@abc-map/module-api"
