// We need this declaration before any imports
import '@abc-map/module-api/src/public-path-setup';
import './translations/i18n';
import { Logger, ModuleFactory } from '@abc-map/module-api';
import { Module } from './Module';

const logger = Logger.get('index.ts', 'info');

/**
 * This is the entrypoint of module. When module will be loaded, this function will be executed.
 *
 * It must return a module instance.
 */
const moduleFactory: ModuleFactory = function (...args: unknown[]) {
  logger.info('Module loaded with arguments: ', args);

  // FIXME
  // FIXME
  // FIXME
  // FIXME
  return new Module();
};

export default moduleFactory;
