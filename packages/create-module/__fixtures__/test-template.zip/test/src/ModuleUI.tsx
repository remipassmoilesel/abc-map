import Styles from './ModuleUI.module.scss';
import * as React from 'react';
import { useCallback, useEffect, useState } from 'react';
import Illustration from './assets/logo.jpg';
import { Parameters, ProcessingProgressEvent, ProgressHandler, Result } from './parameters';
import { setLang } from './translations/i18n';
import { useNoobFormBuilder, Language, Logger } from '@abc-map/module-api';
import { useTranslation } from 'react-i18next';

const logger = Logger.get('ModuleUI.tsx');

interface Props {
  parameters: Parameters;
  onChange: (p: Parameters) => void;
  onProcess: (onProgress: ProgressHandler) => Promise<Result>;
  onCancel: () => void;
  // Lang is injected at runtime
  lang?: Language;
}

export function ModuleUI(props: Props) {
  const { parameters, onChange, onProcess, onCancel, lang } = props;
  const { mainMap } = moduleApi;
  const { t } = useTranslation('Module');
  const formBuilder = useNoobFormBuilder<Parameters>(parameters);
  const [result, setResult] = useState<Result | undefined>();
  const [progress, setProgress] = useState<ProcessingProgressEvent | undefined>();

  // Each time processing progresses, progress is displayed
  const handleProgress = useCallback((event: ProcessingProgressEvent) => setProgress(event), []);

  // Executed when user submits form
  const handleFormSubmit = useCallback(
    (values: Parameters) => {
      onChange(values);
      setResult(undefined);
      setProgress(undefined);

      onProcess(handleProgress)
        .then((result) => setResult(result))
        .catch((err) => {
          logger.error('Processing error: ', err);
          setResult({ errors: [t('Unexpected_error')] });
        });
    },
    [handleProgress, onChange, onProcess, t]
  );

  // We update in memory parameters each time form changes
  useEffect(() => {
    const subscription = formBuilder.onChange((values: Parameters) => onChange(values));
    return () => subscription.unsubscribe();
  }, [formBuilder, onChange]);

  // Update module language when user changes application language
  useEffect(() => {
    setLang(lang || Language.English).catch((err) => logger.error('Language error:', err));
  }, [lang]);

  // Cancel processing when component unmount
  useEffect(() => {
    return () => onCancel();
  }, [onCancel]);

  return (
    <div className={Styles.module}>
      {/* Introduction */}

      <div className={'my-4 d-flex justify-content-between'}>
        {t('This_module_allows_to_create_buffers')}

        <img src={Illustration} alt={'Illustration'} />
      </div>

      {/* Main form.*/}
      {/* You can build trivial forms with formBuilder, a simple helper built with https://react-hook-form.com/api/ */}
      <div>
        {formBuilder
          .addLayerSelector({ name: 'layerId', label: t('Input_layer') }, mainMap)
          .addNumber({ name: 'bufferSize', label: t('Buffer_size') })
          .addSelect(
            {
              name: 'units',
              label: t('Units'),
            },
            [
              { value: 'meters', label: t('Meters') },
              { value: 'kilometers', label: t('Kilometers') },
            ]
          )
          .addCheckboxes(
            {
              name: 'geometrySelection',
              label: t('Geometry_types'),
            },
            [
              { value: 'points', label: t('Points') },
              { value: 'lines', label: t('Lines') },
              { value: 'polygons', label: t('Polygons') },
            ]
          )
          .onSubmit(t('Submit'), handleFormSubmit)
          .build()}
      </div>

      {progress && (
        <div>
          {Math.round((progress.current / progress.total) * 100)} % ({progress.current} / {progress.total})
        </div>
      )}

      {result && (
        <div>
          <div>{t('Processing_done')}</div>

          {!!result.errors.length && (
            <div>
              {t('Errors')}:
              <div>
                {result.errors.map((err) => (
                  <div key={err}>{err}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
