import { ModuleWorker } from './worker';
import { sampleFeatureCollection } from './__fixtures__/sampleFeatureCollection';

describe('worker', function () {
  let worker: ModuleWorker;

  beforeEach(() => {
    worker = new ModuleWorker();
  });

  it('buffer()', () => {
    const buffered = worker.createBuffers({
      collection: sampleFeatureCollection(),
      bufferSize: 15,
      units: 'kilometers',
    });

    expect(buffered).toMatchSnapshot();
  });
});
