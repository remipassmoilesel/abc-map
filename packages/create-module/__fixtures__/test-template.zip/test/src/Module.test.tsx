import { logger, Module } from './Module';
import { initTestModuleApi, newTestFeatureWrapper, newTestLayerWrapper, TestModuleApi } from '../../abc-map_private/packages/module-api';
import { Parameters } from './parameters';
import * as sinon from 'sinon';
import { SinonStubbedInstance } from 'sinon';
import { sampleOpenlayersFeatures } from './__fixtures__/sampleOpenlayersFeatures';
import VectorSource from 'ol/source/Vector';
import { testRemoteWorkerLoader } from './utils/testRemoteWorkerLoader';
import { ModuleWorker } from './worker';
import { Feature } from 'ol';

logger.disable();

/**
 * This is a test file. If you do not want to test your code, you can remove this file safely.
 */
describe('Module', function () {
  let moduleApi: TestModuleApi;
  let worker: SinonStubbedInstance<ModuleWorker>;
  let module: Module;

  beforeEach(() => {
    moduleApi = initTestModuleApi();

    const [context, loader] = testRemoteWorkerLoader();
    worker = context.remote;

    module = new Module(loader);
  });

  it('getReadableName()', () => {
    expect(module.getReadableName()).toEqual('Create buffers (Module template)');
  });

  it('process()', async () => {
    // Prepare
    // We create a fake source layers with 35 features
    const sourceLayer = newTestLayerWrapper();
    sourceLayer.getId.returns('test-layer-id');
    sourceLayer.isVector.returns(true);

    const sourceFeatures = sampleOpenlayersFeatures(35);
    const source = sinon.createStubInstance(VectorSource);
    source.getFeatures.returns(sourceFeatures);
    sourceLayer.getSource.returns(source);

    // We program the main map to return two layers including the one that must be processed
    moduleApi.mainMap.getLayers.returns([newTestLayerWrapper(), sourceLayer]);

    // Calls to FeatureWrapperFactory will return one fake FeatureWrapper
    // This allows to control that all new features have been correctly prepared
    const featureWrapper = newTestFeatureWrapper();
    featureWrapper.unwrap.returns(new Feature());
    moduleApi.FeatureWrapperFactory.from.returns(featureWrapper);

    // Calls to LayerFactory.newVectorLayer() will return one fake LayerWrapper
    const destinationLayer = newTestLayerWrapper();
    const destinationSource = sinon.createStubInstance(VectorSource);
    destinationLayer.getSource.returns(destinationSource);
    moduleApi.LayerFactory.newVectorLayer.returns(destinationLayer);

    // Calls to worker method will return original features
    worker.createBuffers.callsFake((params) => params.collection);

    // Processing parameters
    const parameters: Parameters = {
      layerId: 'test-layer-id',
      bufferSize: 15,
      units: 'kilometers',
      geometrySelection: ['points', 'lines', 'polygons'],
    };
    module.setParameters(parameters);

    const progressHandler = sinon.stub();

    // Act
    const result = await module.process(progressHandler);

    // Assert
    // We expect that the progress has been correctly reported
    expect(progressHandler.callCount).toEqual(4);
    expect(progressHandler.args).toEqual([
      [{ current: 0, total: 35 }],
      [{ current: 15, total: 35 }],
      [{ current: 30, total: 35 }],
      [{ current: 35, total: 35 }],
    ]);

    // We expect that worker has been called correctly
    expect(worker.createBuffers.callCount).toEqual(3);
    expect(worker.createBuffers.args[0][0].bufferSize).toEqual(15);
    expect(worker.createBuffers.args[0][0].units).toEqual('kilometers');

    expect(worker.createBuffers.args[0][0].collection.features[0].id).toEqual(0);
    expect(worker.createBuffers.args[0][0].collection.features[14].id).toEqual(14);

    expect(worker.createBuffers.args[1][0].collection.features[0].id).toEqual(15);
    expect(worker.createBuffers.args[1][0].collection.features[14].id).toEqual(29);

    expect(worker.createBuffers.args[2][0].collection.features[0].id).toEqual(30);
    expect(worker.createBuffers.args[2][0].collection.features[4].id).toEqual(34);

    // All features must have an id and must be styled, then added to source
    expect(featureWrapper.setId.callCount).toEqual(35);
    expect(featureWrapper.setDefaultStyle.callCount).toEqual(35);
    expect(destinationSource.addFeatures.callCount).toEqual(3);

    // No errors must be returned
    expect(result).toEqual({ errors: [] });
  });
});
