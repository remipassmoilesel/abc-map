import { FeatureCollection } from '@turf/helpers';
import GeometryType from 'ol/geom/GeometryType';

export interface Parameters {
  layerId: string;
  bufferSize: number;
  units: 'meters' | 'kilometers';
  geometrySelection: GeometrySelection[];
}

export type GeometrySelection = 'points' | 'lines' | 'polygons';

export function newDefaultParameters(): Parameters {
  return {
    layerId: '',
    bufferSize: 15,
    units: 'kilometers',
    geometrySelection: ['points', 'lines', 'polygons'],
  };
}

export function geometrySelectionToTypes(selection: GeometrySelection[]): string[] {
  const result: string[] = [];
  if (selection.includes('points')) {
    result.push(GeometryType.POINT, GeometryType.MULTI_POINT);
  }
  if (selection.includes('lines')) {
    result.push(GeometryType.LINE_STRING, GeometryType.MULTI_LINE_STRING);
  }
  if (selection.includes('polygons')) {
    result.push(GeometryType.POLYGON, GeometryType.MULTI_POLYGON);
  }

  return result;
}

export interface Result {
  errors: string[];
}

export interface ProcessingProgressEvent {
  total: number;
  current: number;
}

export type ProgressHandler = (ev: ProcessingProgressEvent) => void;

export interface BufferParameters {
  bufferSize: number;
  units: 'meters' | 'kilometers';
  collection: FeatureCollection;
}
