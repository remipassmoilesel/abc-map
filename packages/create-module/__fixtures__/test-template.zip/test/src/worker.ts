import * as Comlink from 'comlink';
import { BufferParameters } from './parameters';
import buffer from '@turf/buffer';
import { toMercator, toWgs84 } from '@turf/projection';
import { FeatureCollection } from '@turf/helpers';

export class ModuleWorker {
  /**
   * Because this worker uses turfjs, all data in input must use EPSG:3857
   * @param parameters
   */
  public createBuffers(parameters: BufferParameters): FeatureCollection {
    const { bufferSize, units, collection: sourceCollection } = parameters;

    const bufferSizeKm = units === 'kilometers' ? bufferSize : bufferSize / 1000;

    const featuresWGS84 = {
      ...sourceCollection,
      features: sourceCollection.features.map((f) => toWgs84(f)),
    };

    const buffered = buffer(featuresWGS84, bufferSizeKm, { units: 'kilometers' });

    return toMercator(buffered);
  }
}

Comlink.expose(new ModuleWorker());
