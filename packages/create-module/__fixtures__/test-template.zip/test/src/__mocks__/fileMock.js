module.exports = 'test-file-stub';
