import * as React from 'react';
import { Module as ModuleInterface, ModuleId, Logger } from '@abc-map/module-api';
import { ModuleUI } from './ModuleUI';
import { newDefaultParameters, Parameters, ProgressHandler, Result, BufferParameters, geometrySelectionToTypes } from './parameters';
import { translation } from './translations/i18n';
import { GeoJSON } from 'ol/format';
import { WorkerContext, remoteWorkerLoader } from './utils/remoteWorkerLoader';
import { Feature } from '@turf/helpers';

export const logger = Logger.get('Module.ts', 'info');

const t = translation('Module:');

/**
 * This is a module. It can be loaded in an instance of Abc-Map.
 *
 * You can access map and various services, process data and eventually inject it back in map.
 *
 */
export class Module implements ModuleInterface {
  private parameters = newDefaultParameters();
  private worker?: WorkerContext;

  constructor(private workerLoader = remoteWorkerLoader) {}

  /**
   * Module id identify the module, in lists and URLs.
   *
   * It must be stable. We recommend you to use a random suffix.
   */
  public getId(): ModuleId {
    return `example-module-${RANDOM_SUFFIX}`;
  }

  /**
   * Readable name will be displayed in list of module and on top of module.
   */
  public getReadableName(): string {
    return t('Create_buffers');
  }

  /**
   * This method returns the main user interface (UI), displayed in Abc-Map. User interface in module
   * is generally used to gather parameters for processing.
   */
  public getUserInterface() {
    return <ModuleUI parameters={this.parameters} onChange={this.setParameters} onProcess={this.process} onCancel={this.handleCancel} />;
  }

  public process = async (onProgress: ProgressHandler): Promise<Result> => {
    logger.info('Start processing using parameters:', this.parameters);
    const result: Result = { errors: [] };
    const { LayerFactory, FeatureWrapperFactory, services, mainMap: map } = moduleApi;
    const { layerId, geometrySelection } = this.parameters;

    // We check that selected layer exists and is a vector layer
    const layer = map.getLayers().find((layer) => layer.getId() === layerId);
    if (!layer || !layer.isVector()) {
      result.errors.push(t('You_must_choose_a_valid_vector_layer'));
      return result;
    }

    // Worker expect data in EPSG:3857, so we load projection for future transforms
    const projection = 'EPSG:3857';
    await services.geo.loadProjection(projection);

    // We filter geometries based on their types
    const geometryTypes = geometrySelectionToTypes(geometrySelection);
    const filtered = layer
      .getSource()
      .getFeatures()
      .filter((feature) => feature.getGeometry() && geometryTypes.includes(feature.getGeometry()?.getType()));

    // We transform geometries to GeoJSON (EPSG:3857) for further buffer processing with turfjs
    const format = new GeoJSON();
    const collection = format.writeFeaturesObject(filtered, { dataProjection: layer.getProjection()?.name, featureProjection: projection });

    // We initialize a new layer
    const total = collection.features.length;
    const newLayer = LayerFactory.newVectorLayer();

    // We process data chunk by chunk in a web worker, in order to not freeze UI and display progress state
    const chunkSize = 15;
    this.worker = await this.workerLoader();
    for (let i = 0; i < total; i += chunkSize) {
      // We create a chunk
      const chunk: BufferParameters = {
        ...this.parameters,
        collection: {
          ...collection,
          features: collection.features.slice(i, i + chunkSize) as Feature[],
        },
      };

      // We create buffers, then prepare them for display in Abc-Map
      const buffered = await this.worker.remote.createBuffers(chunk);
      const projected = format.readFeatures(buffered, { dataProjection: projection, featureProjection: layer.getProjection()?.name });
      const styled = projected.map((feat) => FeatureWrapperFactory.from(feat).setId().setDefaultStyle().unwrap());

      newLayer.getSource().addFeatures(styled);

      onProgress({ total, current: i });
    }

    // End of processing, we add layer
    onProgress({ total, current: total });
    map.addLayer(newLayer);
    return result;
  };

  private handleCancel = () => {
    this.worker?.dispose();
  };

  public setParameters = (parameters: Parameters) => {
    this.parameters = parameters;
  };
}
