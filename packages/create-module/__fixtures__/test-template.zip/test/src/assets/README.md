# Assets

Thanks to webpack, you can embed images, sound, videos, etc. in your modules.

Look at `webpack.config.js` file and [webpack 5](https://webpack.js.org/) documentation in case of problem.
