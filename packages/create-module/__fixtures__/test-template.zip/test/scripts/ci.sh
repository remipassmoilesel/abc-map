#!/usr/bin/env sh

set -e

yarn install
yarn run lint
yarn run build
yarn run test

echo "It works 💪 (maybe)"
